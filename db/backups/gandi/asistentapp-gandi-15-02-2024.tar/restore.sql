--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE asistentapp;
--
-- Name: asistentapp; Type: DATABASE; Schema: -; Owner: hktari
--

CREATE DATABASE asistentapp WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE asistentapp OWNER TO hktari;

\connect asistentapp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.account (
    id bigint NOT NULL,
    email character varying(250) NOT NULL,
    password character varying(250) NOT NULL,
    "automationEnabled" boolean NOT NULL
);


ALTER TABLE public.account OWNER TO hktari;

--
-- Name: TABLE account; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON TABLE public.account IS 'a user has access to the automate asisstant logging app';


--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.account ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: daily_config; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.daily_config (
    id bigint NOT NULL,
    login_info_id bigint NOT NULL,
    date date NOT NULL,
    start_at character varying,
    end_at character varying
);


ALTER TABLE public.daily_config OWNER TO hktari;

--
-- Name: TABLE daily_config; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON TABLE public.daily_config IS 'configurations for logging. On a per day basis';


--
-- Name: daily_config_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.daily_config ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.daily_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: eracuni; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.eracuni (
    its_client_id character varying NOT NULL,
    "itc_SID_homepage" character varying,
    "app_homepage_URL" character varying NOT NULL,
    "app_logged_in_URL" character varying NOT NULL,
    account_id bigint NOT NULL
);


ALTER TABLE public.eracuni OWNER TO hktari;

--
-- Name: log_entry; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.log_entry (
    id bigint NOT NULL,
    login_info_id bigint NOT NULL,
    status character varying(250) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    error character varying,
    message character varying,
    action character varying,
    config_type character varying(50) NOT NULL
);


ALTER TABLE public.log_entry OWNER TO hktari;

--
-- Name: TABLE log_entry; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON TABLE public.log_entry IS 'A log entry contains data of an executed action. When for which user and which action was automated.';


--
-- Name: log_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.log_entry ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.log_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: login_info; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.login_info (
    id bigint NOT NULL,
    account_id bigint NOT NULL,
    username character varying(250) NOT NULL,
    password_cipher bytea NOT NULL,
    iv_cipher bytea NOT NULL
);


ALTER TABLE public.login_info OWNER TO hktari;

--
-- Name: TABLE login_info; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON TABLE public.login_info IS 'a user has login information. Login info contains credentials to login to the assisant web app';


--
-- Name: login_info_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.login_info ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.login_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: work_week_config; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.work_week_config (
    id bigint NOT NULL,
    login_info_id bigint NOT NULL,
    day character varying(250) NOT NULL,
    start_at character varying(250),
    end_at character varying(250)
);


ALTER TABLE public.work_week_config OWNER TO hktari;

--
-- Name: work_week_config_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.work_week_config ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.work_week_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: work_week_exception; Type: TABLE; Schema: public; Owner: hktari
--

CREATE TABLE public.work_week_exception (
    id bigint NOT NULL,
    work_week_config_id bigint NOT NULL,
    date date NOT NULL,
    action character varying(250) NOT NULL
);


ALTER TABLE public.work_week_exception OWNER TO hktari;

--
-- Name: TABLE work_week_exception; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON TABLE public.work_week_exception IS 'ignore work_week_config entry for given date';


--
-- Name: work_week_exception_id_seq; Type: SEQUENCE; Schema: public; Owner: hktari
--

ALTER TABLE public.work_week_exception ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.work_week_exception_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3368.dat

--
-- Data for Name: daily_config; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3376.dat

--
-- Data for Name: eracuni; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3379.dat

--
-- Data for Name: log_entry; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3374.dat

--
-- Data for Name: login_info; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3370.dat

--
-- Data for Name: work_week_config; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3372.dat

--
-- Data for Name: work_week_exception; Type: TABLE DATA; Schema: public; Owner: hktari
--

\i $$PATH$$/3378.dat

--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.account_id_seq', 1, true);


--
-- Name: daily_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.daily_config_id_seq', 10, true);


--
-- Name: log_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.log_entry_id_seq', 20, true);


--
-- Name: login_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.login_info_id_seq', 1, true);


--
-- Name: work_week_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.work_week_config_id_seq', 1, false);


--
-- Name: work_week_exception_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hktari
--

SELECT pg_catalog.setval('public.work_week_exception_id_seq', 1, false);


--
-- Name: work_week_config UNIQUE_USER_DAY; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_config
    ADD CONSTRAINT "UNIQUE_USER_DAY" UNIQUE (login_info_id, day);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: work_week_exception action and date and id; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_exception
    ADD CONSTRAINT "action and date and id" UNIQUE (work_week_config_id, date, action);


--
-- Name: CONSTRAINT "action and date and id" ON work_week_exception; Type: COMMENT; Schema: public; Owner: hktari
--

COMMENT ON CONSTRAINT "action and date and id" ON public.work_week_exception IS 'prevent duplicates for given work week config which have the same date and action';


--
-- Name: daily_config daily_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.daily_config
    ADD CONSTRAINT daily_config_pkey PRIMARY KEY (id);


--
-- Name: daily_config date_login_info; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.daily_config
    ADD CONSTRAINT date_login_info UNIQUE (login_info_id, date);


--
-- Name: account email; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT email UNIQUE (email);


--
-- Name: eracuni eracuni_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.eracuni
    ADD CONSTRAINT eracuni_pkey PRIMARY KEY (account_id);


--
-- Name: login_info login_info_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.login_info
    ADD CONSTRAINT login_info_pkey PRIMARY KEY (id);


--
-- Name: login_info username; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.login_info
    ADD CONSTRAINT username UNIQUE (username);


--
-- Name: work_week_config work_week_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_config
    ADD CONSTRAINT work_week_config_pkey PRIMARY KEY (id);


--
-- Name: work_week_exception work_week_exception_pkey; Type: CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_exception
    ADD CONSTRAINT work_week_exception_pkey PRIMARY KEY (id);


--
-- Name: login_info ACCOUNT; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.login_info
    ADD CONSTRAINT "ACCOUNT" FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE NOT VALID;


--
-- Name: eracuni account; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.eracuni
    ADD CONSTRAINT account FOREIGN KEY (account_id) REFERENCES public.account(id) ON DELETE CASCADE NOT VALID;


--
-- Name: work_week_config login_info; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_config
    ADD CONSTRAINT login_info FOREIGN KEY (login_info_id) REFERENCES public.login_info(id) ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- Name: log_entry login_info; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.log_entry
    ADD CONSTRAINT login_info FOREIGN KEY (login_info_id) REFERENCES public.login_info(id) NOT VALID;


--
-- Name: daily_config login_info; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.daily_config
    ADD CONSTRAINT login_info FOREIGN KEY (login_info_id) REFERENCES public.login_info(id) NOT VALID;


--
-- Name: work_week_exception work_week_config; Type: FK CONSTRAINT; Schema: public; Owner: hktari
--

ALTER TABLE ONLY public.work_week_exception
    ADD CONSTRAINT work_week_config FOREIGN KEY (work_week_config_id) REFERENCES public.work_week_config(id) ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

